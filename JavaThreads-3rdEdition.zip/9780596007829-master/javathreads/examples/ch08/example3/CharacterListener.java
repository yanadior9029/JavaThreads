package javathreads.examples.ch08.example3;

public interface CharacterListener {
    public void newCharacter(CharacterEvent ce);
}
