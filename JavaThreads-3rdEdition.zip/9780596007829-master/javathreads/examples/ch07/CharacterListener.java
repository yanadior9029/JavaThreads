package javathreads.examples.ch07;

public interface CharacterListener {
    public void newCharacter(CharacterEvent ce);
}
