package javathreads.examples.ch11;

public interface CharacterListener {
    public void newCharacter(CharacterEvent ce);
}
